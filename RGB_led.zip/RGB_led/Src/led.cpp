#include "led.h"

LED::LED()
{
	Voltage=0;
	Current=0;
	RCC->AHB1ENR |= LED_PORT_CLOCK;//PORTD Clock call base class constructor from derived class
}

 LED::LED(uint8_t _voltage,uint8_t _current,LedState _status)
{
			Voltage=_voltage;
			Current=_current;
			Status=_status;

			RCC->AHB1ENR |= LED_PORT_CLOCK;//PORTD Clock

}
void LED::Led_state(LedState status) //PD12 LED ON/OFF

		{
			 Status=status;
			 if(Status==ON )
			 {
			 LED_PORT->ODR |= LED_RED_PIN;
			 }
			 else
			 {
			 LED_PORT->ODR &= ~LED_RED_PIN;

			 }
		}

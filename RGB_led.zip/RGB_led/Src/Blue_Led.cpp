#include "led.h"
#include "Blue_Led.h"

Blue_Led::Blue_Led()
		{
			//RCC->AHB1ENR |= LED_PORT_CLOCK;//PORTD Clock call base class constructor from derived class
			LED_PORT->MODER |=LED_BLUE_MODE_BIT;//Set the 12th pin in output mode
		}

void Blue_Led::Blue_Led_toggle(void)
{
	LED_PORT->ODR^=LED_BLUE_PIN;
}
Blue_Led::Blue_Led(uint8_t voltage,uint8_t current)
		//calling base class constructor from derived class
		{
			Blue_Voltage=voltage;
			Blue_Current=current;
			LED_PORT->MODER |=LED_BLUE_MODE_BIT;//Set the 14th pin in output mode



		}
uint32_t Blue_Led::power()
{
	return (Blue_Voltage *Blue_Current);

}

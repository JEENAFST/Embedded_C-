#include "led.h"
#include "Green_Led.h"

Green_Led::Green_Led()
		{
			//RCC->AHB1ENR |= LED_PORT_CLOCK;//PORTD Clock call base class constructor from derived class
			LED_PORT->MODER |=LED_GREEN_MODE_BIT;//Set the 12th pin in output mode
		}

void Green_Led::Green_Led_toggle(void)
{
	LED_PORT->ODR^=LED_GREEN_PIN;
}
Green_Led::Green_Led(uint8_t voltage,uint8_t current)
		//calling base class constructor from derived class
		{
			Green_Voltage=voltage;
			Green_Current=current;
			LED_PORT->MODER |=LED_GREEN_MODE_BIT;//Set the 14th pin in output mode



		}
uint32_t Green_Led::power()
{
	return (Green_Voltage *Green_Current);

}

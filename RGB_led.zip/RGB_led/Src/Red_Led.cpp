#include "led.h"
#include "Red_Led.h"

Red_Led::Red_Led()
{
LED_PORT->MODER |=LED_RED_MODE_BIT;
}
void Red_Led::Red_Led_toggle(void)
{
	LED_PORT->ODR^=LED_RED_PIN;
}
Red_Led::Red_Led(uint8_t voltage,uint8_t current)
		//calling base class constructor from derived class
		{
			Red_Voltage=voltage;
			Red_Current=current;

			LED_PORT->MODER |=LED_RED_MODE_BIT;//Set the 14th pin in output mode
			//RCC->AHB1ENR |= LED_PORT_CLOCK;//PORTD Clock call base class constructor from derived class
			LED_PORT->MODER |=LED_RED_MODE_BIT;//Set the 12th pin in output mode

		}
uint32_t Red_Led::power()
{
	return (Red_Voltage *Red_Current);

}

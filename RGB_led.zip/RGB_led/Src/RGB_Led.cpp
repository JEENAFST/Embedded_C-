#include "led.h"
#include "RGB_Led.h"

RGB_Led::RGB_Led()
		{
	     RGB_Voltage=0;
		 RGB_Current=0;
		}

RGB_Led::RGB_Led(uint8_t voltage,uint8_t current)
		//calling base class constructor from derived class
		{
			RGB_Voltage=voltage;
			RGB_Current=current;

		}
uint32_t RGB_Led::power()
{
	return (RGB_Voltage *RGB_Current);

}


#include "main.h"
#include "led.h"
#include "Red_Led.h"
#include "Green_Led.h"
#include "Blue_Led.h"
#include "RGB_Led.h"
uint8_t volt=0;
int main()
{

   LED L1;
//   Red_Led R1;
//   Green_Led G1;
//   Blue_Led B1;
   RGB_Led RGB1;
   while(1)
   {
   RGB1.Red_Led_toggle();
   RGB1.Green_Led_toggle();
   RGB1.Blue_Led_toggle();
   //RGB1.Voltage=10;//ambiguity problem -diamond issue
   //solve it using Virtual keyword
  //The virtual keyword allows only one copy of the base class to be created, and the object of the derived class can access the members of the base class in the usual way.
   RGB1.Voltage=1;//no error
   Red_Led R1;
   R1.Voltage=3;
   volt=R1.Voltage;//check in live expression
   for(uint32_t i=0 ; i < 300000 ; i++ );



	   }


	return 0;

}




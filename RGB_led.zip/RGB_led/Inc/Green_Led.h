

#ifndef GREEN_LED_H_
#define GREEN_LED_H_

class Green_Led:virtual public LED
{//derived class

private:
		uint8_t Green_Voltage;
		uint8_t Green_Current;


public:
		Green_Led();


		Green_Led(uint8_t voltage,uint8_t current);


		void Green_Led_toggle(void);

		 uint32_t power();


};



#endif /* GREEN_LED_H_ */

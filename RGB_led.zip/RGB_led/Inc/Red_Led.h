

#ifndef RED_LED_H_
#define RED_LED_H_
#include "main.h"
#include "led.h"
class Red_Led: virtual public LED
{//derived class

private:
		uint8_t Red_Voltage;
		uint8_t Red_Current;


public:
		Red_Led();


		Red_Led(uint8_t voltage,uint8_t current);


		void Red_Led_toggle(void);

		 uint32_t power();


};






#endif /* RED_LED_H_ */

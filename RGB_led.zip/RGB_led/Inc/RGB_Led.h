

#ifndef RGB_LED_H_
#define RGB_LED_H_
#include "Red_Led.h"
#include "Green_Led.h"
#include "Blue_Led.h"
class RGB_Led:public Red_Led,public Green_Led,public Blue_Led
{
	//derived class

private:
		uint8_t RGB_Voltage;
		uint8_t RGB_Current;


public:
		RGB_Led();


		RGB_Led(uint8_t voltage,uint8_t current);


		//void RGB_Led_toggle(void);it will inherit the toggle function from other class

		 uint32_t power();


};




#endif /* RGB_LED_H_ */

/*
 * led.h
 *
 *  Created on: Apr 9, 2024
 *      Author: Jeena Sijo
 */
#include "main.h"
#ifndef LED_H_
#define LED_H_
#define	LED_PORT 		GPIOD
//Red Led- PD14
//Green Led - PD12


#define	LED_PORT_CLOCK  (1U<<3)
#define LED_RED_PIN			(1U<<14)
#define LED_GREEN_PIN		(1U<<12)
#define LED_BLUE_PIN		(1U<<15)
#define LED_ORANGE_PIN		(1U<<13)

#define LED_RED_MODE_BIT  (1U<<28)
#define LED_GREEN_MODE_BIT (1U<<24)
#define LED_BLUE_MODE_BIT  (1U<<30)
#define LED_ORANGE_MODE_BIT (1U<<26)

typedef enum{
 OFF =0,
 ON = 1
}LedState;

typedef enum{
 RED=0,
 GREEN= 1,
 ORANGE=2,
 BLUE=3
}Led_Colour;


class LED{

public:
		uint8_t Voltage;
		uint8_t Current;
		LedState Status;


        LED();
		LED(uint8_t _voltage,uint8_t _current,LedState _status);

		void Led_state(LedState status); //PD12 LED ON/OFF
		//

};




#endif /* LED_H_ */

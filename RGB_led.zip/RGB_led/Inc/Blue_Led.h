

#ifndef BLUE_LED_H_
#define BLUE_LED_H_


class Blue_Led:virtual public LED
{//derived class

private:
		uint8_t Blue_Voltage;
		uint8_t Blue_Current;


public:
		Blue_Led();


		Blue_Led(uint8_t voltage,uint8_t current);


		void Blue_Led_toggle(void);

		 uint32_t power();


};



#endif /* BLUE_LED_H_ */

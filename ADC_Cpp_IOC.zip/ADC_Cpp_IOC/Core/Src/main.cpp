/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "usb_host.h"

#include "adc.h"





uint32_t  sensor_value;

int main()
{

  HAL_Init();


  adc_init_start();

  while(1)
  {
	  sensor_value =  pa0_adc_read();
  }
}



void  SysTick_Handler(void)
{
	HAL_IncTick();
}
